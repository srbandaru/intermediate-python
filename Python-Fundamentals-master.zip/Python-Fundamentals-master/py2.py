name = raw_input('Enter your name: ')
print 'Hi', name, 'how are you?'
