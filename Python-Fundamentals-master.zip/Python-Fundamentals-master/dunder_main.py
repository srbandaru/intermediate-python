# Try running this directly vs. import-ing it

some_data = 'something'
print('__name__ is', __name__)

if __name__ == '__main__':
    print('run some tests')

